The long list of other openframework UI addons are nice but I wanted to have options that didn't require panels and allowed for more freedom in their style. Buttons can be toggles or momentary. I also wanted color pickers of all sorts of sizes and styles. Text entry and sliders too

##List of Features
* Image Buttons
* Normal Buttons
* Color Pickers
* Text Fields
* Dropdown Menus 
* Sliders 

Includes @Flightphase ofxTextInputField as the current text input methods, works well for the light weight nature of the utilities.

Utilizes a font renderer so that button fonts and input fields can be something other than a bitmapfont

Drop down menus adapted from @igiso's ofxCopyPasteText



## To Do:
* Make more customizable Sliders
